from . import use
spam = 1
